import { $t } from "@/plugins/i18n";

export default {
  path: "/user",
  name: "用户管理",
  meta: {
    icon: "informationLine",
    title: $t("menus.lghUser"),
    rank: 6
  },
  children: [
    {
      path: "/permission",
      name: "permission",
      component: () => import("@/views/subject/index.vue"),
      meta: {
        title: $t("menus.lghPermission")
      }
    },
    {
      path: "/role",
      name: "role",
      component: () => import("@/views/knowledge/index.vue"),
      meta: {
        title: $t("menus.lghRole")
      }
    },
    {
      path: "/user",
      name: "user",
      component: () => import("@/views/user/index.vue"),
      meta: {
        title: $t("menus.lghUser")
      }
    },
    {
      path: "/class",
      name: "class",
      component: () => import("@/views/question/index.vue"),
      meta: {
        title: $t("menus.lghClass")
      }
    }
  ]
} as RouteConfigsTable;
